import google.generativeai as genai

print("hello")

